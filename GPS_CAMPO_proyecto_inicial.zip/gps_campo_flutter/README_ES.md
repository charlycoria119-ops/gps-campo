# GPS CAMPO — proyecto inicial

Este es un **prototipo de código fuente Flutter**, no un APK compilado.

## Funciones incluidas en esta primera base
- Interfaz en español y modo oscuro.
- Mapa base OpenStreetMap cuando hay conexión.
- Lectura de ubicación GPS.
- Inicio/detención de registro de puntos.
- Guardado local de recorridos.
- Marcador de vehículo.
- Distancia en línea recta al vehículo.
- Vista de recorridos guardados.
- Brújula si el dispositivo dispone de sensor.

## Importante: limitaciones que faltan resolver antes de usar en el campo
1. **Mapas sin conexión:** esta base todavía no descarga ni muestra paquetes de mapas offline. La capa actual usa internet. Hay que integrar y probar almacenamiento local de mapas (por ejemplo, paquetes MBTiles o caché de teselas con licencia y atribución adecuadas).
2. **Seguimiento con pantalla apagada:** se agregó el flujo de ubicación, pero todavía hay que integrar un servicio Android de primer plano persistente y probarlo en distintos fabricantes. No se debe confiar en este prototipo para regresar de noche.
3. **Volver al vehículo:** por ahora centra el mapa e informa distancia en línea recta; falta navegación inversa siguiendo el sendero registrado.
4. **Asistente IA:** el botón es una indicación visual; falta conectar un servicio de IA y definir costos/privacidad.
5. **Seguridad:** probar precisión GPS, permisos, batería y recuperación tras reinicio antes de cualquier salida real.

## Requisitos para compilar
- Flutter SDK estable.
- Android Studio y Android SDK.
- JDK compatible con la versión de Flutter instalada.

## Comandos
```bash
flutter pub get
flutter run
flutter build apk --release
```
El APK de salida se genera normalmente en:
`build/app/outputs/flutter-apk/app-release.apk`

## Punto inicial de prueba
El mapa abre centrado en las coordenadas compartidas para Loreto, Santiago del Estero:
- Latitud: -28.585866
- Longitud: -64.276489

## Privacidad y uso responsable
La ubicación es información sensible. Antes de publicar, incorporar una política de privacidad clara, controles para borrar recorridos y explicar si se comparte algún dato. El registro debe ser visible y voluntario.

## Compilar desde el celular usando GitHub Actions (sin computadora)
Este ZIP incluye `.github/workflows/build-apk.yml` para compilar en la nube. En un navegador del teléfono:
1. Crear una cuenta en GitHub e iniciar sesión.
2. Crear un repositorio nuevo y subir el contenido de este ZIP (descomprimido).
3. Abrir la pestaña **Actions** del repositorio.
4. Elegir **Construir APK GPS CAMPO** y tocar **Run workflow**.
5. Cuando termine, abrir la ejecución y descargar el artefacto **gps-campo-apk**.

La compilación en la nube solo genera un APK de prueba de esta base inicial. No convierte en reales las funciones pendientes indicadas arriba; en particular, no usar todavía para navegación de seguridad ni para salir al campo sin otro medio de orientación.
