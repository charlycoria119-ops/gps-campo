import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_compass/flutter_compass.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const GPSCampoApp());

const Color bg = Color(0xFF0B1117);
const Color panel = Color(0xFF17232D);
const Color accent = Color(0xFF42D392);

class GPSCampoApp extends StatelessWidget {
  const GPSCampoApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'GPS CAMPO',
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: accent, surface: panel),
      cardColor: panel,
    ),
    home: const HomePage(),
  );
}

class TrackPoint {
  final double lat, lon;
  final DateTime time;
  TrackPoint(this.lat, this.lon, this.time);
  Map<String, dynamic> toJson() => {'lat': lat, 'lon': lon, 'time': time.toIso8601String()};
  factory TrackPoint.fromJson(Map<String, dynamic> j) =>
      TrackPoint((j['lat'] as num).toDouble(), (j['lon'] as num).toDouble(), DateTime.parse(j['time']));
  LatLng get ll => LatLng(lat, lon);
}

class SavedTrack {
  final String name;
  final DateTime started;
  final List<TrackPoint> points;
  SavedTrack(this.name, this.started, this.points);
  Map<String, dynamic> toJson() => {
    'name': name, 'started': started.toIso8601String(),
    'points': points.map((p) => p.toJson()).toList()
  };
  factory SavedTrack.fromJson(Map<String, dynamic> j) => SavedTrack(
    j['name'], DateTime.parse(j['started']),
    (j['points'] as List).map((p) => TrackPoint.fromJson(Map<String, dynamic>.from(p))).toList()
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  final MapController map = MapController();
  StreamSubscription<Position>? gpsSub;
  StreamSubscription<CompassEvent>? compassSub;
  Position? current;
  Position? vehicle;
  final List<TrackPoint> activePoints = [];
  List<SavedTrack> saved = [];
  bool recording = false;
  bool gpsReady = false;
  double? heading;
  DateTime? started;
  String status = 'Esperando GPS';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadSaved();
    _initGps();
    compassSub = FlutterCompass.events?.listen((e) {
      if (mounted) setState(() => heading = e.heading);
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    gpsSub?.cancel();
    compassSub?.cancel();
    super.dispose();
  }

  Future<void> _loadSaved() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList('tracks') ?? [];
    saved = raw.map((s) => SavedTrack.fromJson(jsonDecode(s))).toList();
    if (mounted) setState(() {});
  }

  Future<void> _persist() async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('tracks', saved.map((t) => jsonEncode(t.toJson())).toList());
  }

  Future<bool> _permissions() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      setState(() => status = 'Activá la ubicación del teléfono');
      return false;
    }
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
      setState(() => status = 'Falta permiso de ubicación');
      return false;
    }
    return true;
  }

  Future<void> _initGps() async {
    if (!await _permissions()) return;
    try {
      final p = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.best, timeLimit: Duration(seconds: 20)),
      );
      if (!mounted) return;
      setState(() { current = p; gpsReady = true; status = 'GPS conectado'; });
      map.move(LatLng(p.latitude, p.longitude), 15);
    } catch (_) {
      if (mounted) setState(() => status = 'Buscando señal GPS…');
    }
  }

  Future<void> _start() async {
    if (!await _permissions()) return;
    setState(() {
      recording = true;
      started = DateTime.now();
      activePoints.clear();
      status = 'Grabando recorrido';
      if (vehicle == null && current != null) vehicle = current;
    });
    const settings = LocationSettings(
      accuracy: LocationAccuracy.bestForNavigation,
      distanceFilter: 3,
      timeLimit: Duration(minutes: 5),
    );
    gpsSub?.cancel();
    gpsSub = Geolocator.getPositionStream(locationSettings: settings).listen((p) {
      if (!mounted) return;
      setState(() {
        current = p;
        gpsReady = true;
        activePoints.add(TrackPoint(p.latitude, p.longitude, p.timestamp));
        status = 'Grabando recorrido';
      });
      map.move(LatLng(p.latitude, p.longitude), map.camera.zoom);
    }, onError: (_) {
      if (mounted) setState(() => status = 'Señal GPS interrumpida');
    });
  }

  Future<void> _stop() async {
    await gpsSub?.cancel();
    gpsSub = null;
    if (activePoints.isNotEmpty) {
      final track = SavedTrack(
        'Recorrido ${saved.length + 1}',
        started ?? DateTime.now(),
        List<TrackPoint>.from(activePoints),
      );
      saved.insert(0, track);
      await _persist();
    }
    if (mounted) setState(() { recording = false; status = 'Recorrido guardado'; });
  }

  void _markVehicle() {
    if (current == null) return;
    setState(() { vehicle = current; status = 'Vehículo marcado'; });
  }

  void _returnToVehicle() {
    if (vehicle == null) {
      _markVehicle();
      return;
    }
    if (current != null) {
      map.move(LatLng(current!.latitude, current!.longitude), 16);
      final meters = Geolocator.distanceBetween(
        current!.latitude, current!.longitude, vehicle!.latitude, vehicle!.longitude);
      setState(() => status = 'Vehículo a ${meters.toStringAsFixed(0)} m en línea recta');
    }
  }

  double _distance(List<TrackPoint> points) {
    double total = 0;
    for (int i = 1; i < points.length; i++) {
      total += Geolocator.distanceBetween(points[i-1].lat, points[i-1].lon, points[i].lat, points[i].lon);
    }
    return total;
  }

  void _showTracks() {
    showModalBottomSheet(
      context: context, backgroundColor: panel, isScrollControlled: true,
      builder: (_) => SafeArea(child: SizedBox(height: 420, child: Column(children: [
        const Padding(padding: EdgeInsets.all(16), child: Text('RECORRIDOS GUARDADOS', style: TextStyle(fontWeight: FontWeight.bold))),
        Expanded(child: saved.isEmpty
          ? const Center(child: Text('Todavía no hay recorridos guardados'))
          : ListView.builder(itemCount: saved.length, itemBuilder: (_, i) {
              final t = saved[i];
              return ListTile(
                leading: const Icon(Icons.route, color: accent),
                title: Text(t.name),
                subtitle: Text('${t.started.toLocal()} • ${(_distance(t.points)/1000).toStringAsFixed(2)} km'),
                trailing: IconButton(icon: const Icon(Icons.visibility), onPressed: () {
                  Navigator.pop(context);
                  if (t.points.isNotEmpty) {
                    map.move(t.points.first.ll, 15);
                    setState(() { status = 'Viendo ${t.name}'; });
                  }
                }),
              );
            })),
      ]))),
    );
  }

  @override
  Widget build(BuildContext context) {
    final here = current == null ? null : LatLng(current!.latitude, current!.longitude);
    final vehicleLL = vehicle == null ? null : LatLng(vehicle!.latitude, vehicle!.longitude);
    final line = activePoints.map((p) => p.ll).toList();
    return Scaffold(
      body: SafeArea(child: Stack(children: [
        FlutterMap(
          mapController: map,
          options: MapOptions(initialCenter: const LatLng(-28.585866, -64.276489), initialZoom: 12),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.gpscampo.app',
            ),
            if (line.length > 1) PolylineLayer(polylines: [Polyline(points: line, strokeWidth: 4, color: accent)]),
            MarkerLayer(markers: [
              if (here != null) Marker(point: here, width: 44, height: 44, child: const Icon(Icons.my_location, color: Colors.blueAccent, size: 34)),
              if (vehicleLL != null) Marker(point: vehicleLL, width: 44, height: 44, child: const Icon(Icons.local_parking, color: Colors.orange, size: 34)),
            ]),
          ],
        ),
        Positioned(top: 12, left: 12, right: 12, child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(color: bg.withOpacity(.94), borderRadius: BorderRadius.circular(16)),
          child: Row(children: [
            const Icon(Icons.explore, color: accent, size: 30),
            const SizedBox(width: 10),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('GPS CAMPO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2, fontSize: 18)),
              Text('Orientación y recorridos', style: TextStyle(color: Colors.white70, fontSize: 11)),
            ])),
            Icon(recording ? Icons.fiber_manual_record : Icons.gps_fixed,
              color: recording ? Colors.redAccent : accent),
          ]),
        )),
        Positioned(left: 12, right: 12, bottom: 16, child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: bg.withOpacity(.94), borderRadius: BorderRadius.circular(16)),
            child: Row(children: [
              const Icon(Icons.satellite_alt, color: accent),
              const SizedBox(width: 8),
              Expanded(child: Text(status, style: const TextStyle(fontWeight: FontWeight.w600))),
              if (current != null) Text('${current!.accuracy.toStringAsFixed(0)} m', style: const TextStyle(color: Colors.white60, fontSize: 12)),
            ]),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: _actionButton(
              recording ? 'DETENER' : 'INICIAR',
              recording ? Icons.stop_circle : Icons.play_circle_fill,
              recording ? Colors.redAccent : accent,
              recording ? _stop : _start,
            )),
            const SizedBox(width: 8),
            _smallButton(Icons.local_parking, 'VEHÍCULO', _markVehicle),
            const SizedBox(width: 8),
            _smallButton(Icons.assistant_navigation, 'VOLVER', _returnToVehicle),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: _smallButton(Icons.route, 'MIS RECORRIDOS', _showTracks)),
            const SizedBox(width: 8),
            Expanded(child: _smallButton(Icons.smart_toy, 'ASISTENTE IA', () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('El asistente IA se conectará cuando esté disponible internet.')));
            })),
            const SizedBox(width: 8),
            _smallButton(Icons.my_location, 'CENTRAR', () {
              if (here != null) map.move(here, 16); else _initGps();
            }),
          ]),
          if (heading != null) Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text('BRÚJULA  ${heading!.toStringAsFixed(0)}°', style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ),
        ])),
      ])),
    );
  }

  Widget _actionButton(String label, IconData icon, Color color, VoidCallback onTap) => Expanded(
    child: SizedBox(height: 58, child: ElevatedButton.icon(
      onPressed: onTap, icon: Icon(icon, size: 26),
      label: Text(label, style: const TextStyle(fontWeight: FontWeight.w900)),
      style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: Colors.black,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
    )),
  );

  Widget _smallButton(IconData icon, String label, VoidCallback onTap) => Expanded(
    child: SizedBox(height: 58, child: ElevatedButton(
      onPressed: onTap, style: ElevatedButton.styleFrom(backgroundColor: panel,
        foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 21, color: accent), const SizedBox(height: 3),
        FittedBox(child: Text(label, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold))),
      ]),
    )),
  );
}
